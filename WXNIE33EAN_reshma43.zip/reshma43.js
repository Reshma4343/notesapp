// Element references
const titleInput = document.getElementById("note-title");
const contentInput = document.getElementById("note-content");
const tagsInput = document.getElementById("note-tags");
const saveBtn = document.getElementById("save-note");
const notesContainer = document.getElementById("notes-container");
const searchInput = document.getElementById("search-input");
const themeToggle = document.getElementById("theme-toggle");

// Notes array
let notes = JSON.parse(localStorage.getItem("notes")) || [];
let isDark = localStorage.getItem("theme") === "dark";

// Initialize
document.body.classList.toggle("dark", isDark);
renderNotes();

// Save Note
saveBtn.addEventListener("click", () => {
    const title = titleInput.value.trim();
    const content = contentInput.value.trim();
    const tags = tagsInput.value.trim().split(',').map(tag => tag.trim());

    if (!title || !content) return alert("Title and content are required!");

    const note = {
        id: Date.now(),
        title,
        content,
        tags,
        pinned: false,
        timestamp: new Date().toLocaleString()
    };

    notes.push(note);
    saveAndRender();
    clearInputs();
});

// Render Notes
function renderNotes() {
    notesContainer.innerHTML = "";

    const filteredNotes = notes
        .filter(note =>
            note.title.toLowerCase().includes(searchInput.value.toLowerCase()) ||
            note.content.toLowerCase().includes(searchInput.value.toLowerCase())
        )
        .sort((a, b) => b.pinned - a.pinned);

    filteredNotes.forEach(note => {
        const card = document.createElement("div");
        card.className = `note-card ${isDark ? "dark" : ""}`;
        card.innerHTML = `
      <div class="note-header">
        <strong>${note.title}</strong>
        <span>${note.timestamp}</span>
      </div>
      <p>${note.content}</p>
      <div><small>Tags: ${note.tags.join(", ")}</small></div>
      <div class="note-actions">
        <button onclick="editNote(${note.id})">Edit</button>
        <button onclick="deleteNote(${note.id})">Delete</button>
        <button onclick="togglePin(${note.id})">${note.pinned ? "Unpin" : "Pin"}</button>
      </div>
    `;
        notesContainer.appendChild(card);
    });
}

// Delete Note
function deleteNote(id) {
    notes = notes.filter(note => note.id !== id);
    saveAndRender();
}

// Edit Note
function editNote(id) {
    const note = notes.find(n => n.id === id);
    if (!note) return;

    titleInput.value = note.title;
    contentInput.value = note.content;
    tagsInput.value = note.tags.join(", ");

    deleteNote(id); // Remove old note; will be replaced on save
}

// Toggle Pin
function togglePin(id) {
    notes = notes.map(n => n.id === id ? {
        ...n,
        pinned: !n.pinned
    } : n);
    saveAndRender();
}

// Save to LocalStorage & Re-render
function saveAndRender() {
    localStorage.setItem("notes", JSON.stringify(notes));
    renderNotes();
}

document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('note-form');
    const titleInput = document.getElementById('note-title');
    const contentInput = document.getElementById('note-content');
    const notesContainer = document.getElementById('notes-container');

    let notes = JSON.parse(localStorage.getItem('notes')) || [];

    const saveNotes = () => {
        localStorage.setItem('notes', JSON.stringify(notes));
    };

    const renderNotes = () => {
        notesContainer.innerHTML = '';
        notes.forEach((note, index) => {
            const noteCard = document.createElement('div');
            noteCard.classList.add('note-card');

            const noteTitle = document.createElement('h3');
            noteTitle.textContent = note.title;

            const noteContent = document.createElement('p');
            noteContent.textContent = note.content;

            const timestamp = document.createElement('div');
            timestamp.classList.add('timestamp');
            timestamp.textContent = new Date(note.timestamp).toLocaleString();

            const deleteBtn = document.createElement('button');
            deleteBtn.textContent = 'Delete';
            deleteBtn.addEventListener('click', () => {
                notes.splice(index, 1);
                saveNotes();
                renderNotes();
            });

            const editBtn = document.createElement('button');
            editBtn.textContent = 'Edit';
            editBtn.style.right = '60px';
            editBtn.addEventListener('click', () => {
                titleInput.value = note.title;
                contentInput.value = note.content;
                notes.splice(index, 1);
                saveNotes();
                renderNotes();
            });

            noteCard.appendChild(noteTitle);
            noteCard.appendChild(noteContent);
            noteCard.appendChild(timestamp);
            noteCard.appendChild(deleteBtn);
            noteCard.appendChild(editBtn);

            notesContainer.appendChild(noteCard);
        });
    };

    form.addEventListener('submit', (e) => {
        e.preventDefault();
        const newNote = {
            title: titleInput.value,
            content: contentInput.value,
            timestamp: Date.now(),
        };
        notes.push(newNote);
        saveNotes();
        renderNotes();
        form.reset();
    });

    renderNotes();
});

// Clear input fields
function clearInputs() {
    titleInput.value = "";
    contentInput.value = "";
    tagsInput.value = "";
}

// Search Notes
searchInput.addEventListener("input", renderNotes);

// Toggle Theme
themeToggle.addEventListener("click", () => {
    isDark = !isDark;
    document.body.classList.toggle("dark", isDark);
    localStorage.setItem("theme", isDark ? "dark" : "light");
    renderNotes();
});